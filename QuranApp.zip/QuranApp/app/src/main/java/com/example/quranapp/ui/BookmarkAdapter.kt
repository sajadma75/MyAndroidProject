package com.example.quranapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.quranapp.data.models.BookmarkWithDetails
import com.example.quranapp.databinding.ItemBookmarkBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BookmarkAdapter(
    private val onBookmarkClick: (BookmarkWithDetails) -> Unit,
    private val onRemoveClick: (BookmarkWithDetails) -> Unit
) : ListAdapter<BookmarkWithDetails, BookmarkAdapter.BookmarkViewHolder>(BookmarkDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookmarkViewHolder {
        val binding = ItemBookmarkBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return BookmarkViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BookmarkViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class BookmarkViewHolder(private val binding: ItemBookmarkBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onBookmarkClick(getItem(position))
                }
            }

            binding.btnRemove.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onRemoveClick(getItem(position))
                }
            }
        }

        fun bind(bookmark: BookmarkWithDetails) {
            binding.apply {
                surahName.text = "سوره ${bookmark.surahName}"
                ayahNumber.text = "آیه ${bookmark.ayahNumber}"
                bookmarkDate.text = formatDate(bookmark.bookmark.timestamp)
            }
        }

        private fun formatDate(timestamp: Long): String {
            val date = Date(timestamp)
            val format = SimpleDateFormat("yyyy/MM/dd", Locale("fa"))
            return format.format(date)
        }
    }

    class BookmarkDiffCallback : DiffUtil.ItemCallback<BookmarkWithDetails>() {
        override fun areItemsTheSame(oldItem: BookmarkWithDetails, newItem: BookmarkWithDetails): Boolean {
            return oldItem.bookmark.id == newItem.bookmark.id
        }

        override fun areContentsTheSame(oldItem: BookmarkWithDetails, newItem: BookmarkWithDetails): Boolean {
            return oldItem == newItem
        }
    }
}
