package com.example.quranapp.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.quranapp.data.QuranDatabase
import com.example.quranapp.data.QuranRepository
import com.example.quranapp.data.models.Ayah
import com.example.quranapp.data.models.Bookmark
import com.example.quranapp.data.models.Surah
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val bookmarkDao = QuranDatabase.getDatabase(application).bookmarkDao()
    private val repository = QuranRepository(bookmarkDao)

    private val _surahs = MutableLiveData<List<Surah>>()
    val surahs: LiveData<List<Surah>> get() = _surahs

    private val _ayahs = MutableLiveData<List<Ayah>>()
    val ayahs: LiveData<List<Ayah>> get() = _ayahs

    private val _bookmarks = MutableLiveData<List<Bookmark>>()
    val bookmarks: LiveData<List<Bookmark>> get() = _bookmarks

    private val _searchResults = MutableLiveData<List<Ayah>>()
    val searchResults: LiveData<List<Ayah>> get() = _searchResults

    fun getSurahs() {
        viewModelScope.launch {
            _surahs.value = repository.getSurahs()
        }
    }

    fun getAyahsForSurah(surahId: Int) {
        viewModelScope.launch {
            _ayahs.value = repository.getAyahsForSurah(surahId)
        }
    }

    fun searchAyahs(query: String) {
        viewModelScope.launch {
            _searchResults.value = repository.searchAyahs(query)
        }
    }

    fun getBookmarks() {
        viewModelScope.launch {
            _bookmarks.value = repository.getBookmarks()
        }
    }

    fun addBookmark(ayah: Ayah) {
        viewModelScope.launch {
            repository.addBookmark(ayah)
            getBookmarks()
        }
    }

    fun removeBookmark(bookmark: Bookmark) {
        viewModelScope.launch {
            repository.removeBookmark(bookmark)
            getBookmarks()
        }
    }

    // متد جدید برای گرفتن لیست آیات بر اساس سوره
    fun getAyahsBySurah(surahId: Int): LiveData<List<Ayah>> {
        val ayahsLiveData = MutableLiveData<List<Ayah>>()
        viewModelScope.launch {
            ayahsLiveData.value = repository.getAyahsForSurah(surahId)
        }
        return ayahsLiveData
    }

    // متد جدید برای گرفتن یک بوکمارک خاص
    fun getBookmark(surahId: Int, ayahId: Int): LiveData<Bookmark?> {
        val bookmarkLiveData = MutableLiveData<Bookmark?>()
        viewModelScope.launch {
            bookmarkLiveData.value = repository.getBookmark(surahId, ayahId)
        }
        return bookmarkLiveData
    }

    // متد جدید برای افزودن بوکمارک با آیدی‌ها
    fun addBookmark(surahId: Int, ayahId: Int) {
        viewModelScope.launch {
            repository.addBookmarkByIds(surahId, ayahId)
            getBookmarks()
        }
    }
}
