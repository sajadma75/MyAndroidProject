package com.example.quranapp.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.quranapp.data.models.Ayah
import com.example.quranapp.databinding.ItemAyahBinding

class AyahAdapter(
    private val onBookmarkClick: (Ayah) -> Unit,
    private val onPlayClick: (Ayah) -> Unit,
    private val onShareClick: (Ayah) -> Unit,
    private val onCopyClick: (Ayah) -> Unit
) : ListAdapter<Ayah, AyahAdapter.AyahViewHolder>(AyahDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AyahViewHolder {
        val binding = ItemAyahBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return AyahViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AyahViewHolder, position: Int) {
        val ayah = getItem(position)
        holder.bind(ayah)

        // تنظیم اندازه متن و نمایش ترجمه
        holder.binding.ayahText.textSize = getArabicTextSize(holder.itemView.context)
        holder.binding.ayahTranslation.textSize = getTranslationTextSize(holder.itemView.context)
        holder.binding.ayahTranslation.visibility = if (isTranslationVisible(holder.itemView.context)) View.VISIBLE else View.GONE
    }

    inner class AyahViewHolder(val binding: ItemAyahBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(ayah: Ayah) {
            binding.apply {
                ayahNumber.text = ayah.ayahNumber.toString()
                ayahText.text = ayah.text
                ayahTranslation.text = ayah.translation

                btnBookmark.setOnClickListener {
                    onBookmarkClick(ayah)
                }

                btnPlay.setOnClickListener {
                    onPlayClick(ayah)
                }

                buttonShare.setOnClickListener {
                    onShareClick(ayah)
                }

                buttonCopy.setOnClickListener {
                    onCopyClick(ayah)
                }
            }
        }
    }

    private fun getArabicTextSize(context: Context): Float {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val textSize = prefs.getString("arabic_text_size", "18")?.toFloatOrNull() ?: 18f
        return textSize
    }

    private fun getTranslationTextSize(context: Context): Float {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val textSize = prefs.getString("translation_text_size", "14")?.toFloatOrNull() ?: 14f
        return textSize
    }

    private fun isTranslationVisible(context: Context): Boolean {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        return prefs.getBoolean("show_translation", true)
    }

    class AyahDiffCallback : DiffUtil.ItemCallback<Ayah>() {
        override fun areItemsTheSame(oldItem: Ayah, newItem: Ayah): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Ayah, newItem: Ayah): Boolean {
            return oldItem == newItem
        }
    }
}
