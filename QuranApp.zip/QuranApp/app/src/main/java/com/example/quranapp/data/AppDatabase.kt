package com.example.quranapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.quranapp.data.SurahDao
import com.example.quranapp.data.AyahDao
import com.example.quranapp.data.models.Surah
import com.example.quranapp.data.models.Ayah

@Database(entities = [Surah::class, Ayah::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun surahDao(): SurahDao
    abstract fun ayahDao(): AyahDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "quran_database"
                )
                    .addCallback(DataInitializer(context))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
