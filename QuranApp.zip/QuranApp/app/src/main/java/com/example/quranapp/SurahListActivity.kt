package com.example.quranapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.quranapp.databinding.ActivitySurahListBinding
import com.example.quranapp.ui.MainViewModel
import com.example.quranapp.ui.SurahAdapter

class SurahListActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySurahListBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: SurahAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySurahListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        observeSurahs()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "سوره‌های قرآن"
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun setupRecyclerView() {
        adapter = SurahAdapter { surah ->
            val intent = Intent(this, AyahListActivity::class.java).apply {
                putExtra("SURAH_ID", surah.id)
                putExtra("SURAH_NAME", surah.name)
            }
            startActivity(intent)
        }

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@SurahListActivity)
            adapter = this@SurahListActivity.adapter
        }
    }

    private fun observeSurahs() {
        viewModel.allSurahs.observe(this) { surahs ->
            adapter.submitList(surahs)
        }
    }
}
