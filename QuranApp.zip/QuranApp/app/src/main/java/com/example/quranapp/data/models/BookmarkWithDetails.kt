package com.example.quranapp.data.models

data class BookmarkWithDetails(
    val bookmark: Bookmark,
    val surahName: String,
    val ayahNumber: Int,
    val ayahText: String
)
