package com.example.quranapp

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.quranapp.data.models.Ayah
import com.example.quranapp.databinding.ActivityAyahListBinding
import com.example.quranapp.ui.AyahAdapter
import com.example.quranapp.ui.MainViewModel

class AyahListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAyahListBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: AyahAdapter
    private var mediaPlayer: MediaPlayer? = null
    private var surahId: Int = 0
    private var surahName: String = ""

    private val settingsChangedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.quranapp.TEXT_SETTINGS_CHANGED") {
                adapter.notifyDataSetChanged()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAyahListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        surahId = intent.getIntExtra("SURAH_ID", 1)
        surahName = intent.getStringExtra("SURAH_NAME") ?: "سوره"

        setupToolbar()
        setupRecyclerView()
        observeAyahs()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = surahName
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun setupRecyclerView() {
        adapter = AyahAdapter(
            onBookmarkClick = { ayah ->
                toggleBookmark(ayah)
            },
            onPlayClick = { ayah ->
                playAudio(ayah)
            },
            onShareClick = { ayah ->
                shareAyah(ayah)
            },
            onCopyClick = { ayah ->
                copyAyah(ayah)
            }
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@AyahListActivity)
            adapter = this@AyahListActivity.adapter

            // Add scroll listener for lazy loading
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)

                    // Hide/show toolbar based on scroll direction
                    if (dy > 0) {
                        binding.toolbar.animate().translationY(-binding.toolbar.height.toFloat()).setDuration(300).start()
                    } else if (dy < 0) {
                        binding.toolbar.animate().translationY(0f).setDuration(300).start()
                    }
                }
            })
        }
    }

    private fun observeAyahs() {
        viewModel.getAyahsBySurah(surahId).observe(this) { ayahs ->
            adapter.submitList(ayahs)
        }
    }

    private fun toggleBookmark(ayah: Ayah) {
        viewModel.getBookmark(ayah.surahId, ayah.id).observe(this) { bookmark ->
            if (bookmark == null) {
                viewModel.addBookmark(ayah.surahId, ayah.id)
                Toast.makeText(this, "نشانک اضافه شد", Toast.LENGTH_SHORT).show()
            } else {
                viewModel.removeBookmark(bookmark)
                Toast.makeText(this, "نشانک حذف شد", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun playAudio(ayah: Ayah) {
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(ayah.audioUrl)
                prepareAsync()
                setOnPreparedListener {
                    start()
                }
                setOnErrorListener { _, _, _ ->
                    Toast.makeText(this@AyahListActivity, "خطا در پخش صوت", Toast.LENGTH_SHORT).show()
                    true
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در پخش صوت: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareAyah(ayah: Ayah) {
        val shareText = "${ayah.text}\n\n${ayah.translation}\n\n(سوره ${surahName} - آیه ${ayah.ayahNumber})"
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "اشتراک‌گذاری آیه")
        startActivity(shareIntent)
    }

    private fun copyAyah(ayah: Ayah) {
        val copyText = "${ayah.text}\n\n${ayah.translation}\n\n(سوره ${surahName} - آیه ${ayah.ayahNumber})"
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("آیه قرآن", copyText)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "آیه کپی شد", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(settingsChangedReceiver, IntentFilter("com.example.quranapp.TEXT_SETTINGS_CHANGED"))
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(settingsChangedReceiver)
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
