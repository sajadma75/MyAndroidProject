package com.example.quranapp.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val surahId: Int,
    val ayahId: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val note: String? = null
)
