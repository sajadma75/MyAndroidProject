package com.example.quranapp.ui

import android.app.TimePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import com.example.quranapp.BuildConfig
import com.example.quranapp.R
import com.example.quranapp.utils.ReminderManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class SettingsFragment : PreferenceFragmentCompat(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var reminderManager: ReminderManager
    private var reminderHour = 8
    private var reminderMinute = 0

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        reminderManager = ReminderManager(requireContext())

        // Set app version
        val versionPreference = findPreference<Preference>("app_version")
        versionPreference?.summary = "نسخه ${BuildConfig.VERSION_NAME}"

        // Set about us click listener
        val aboutUsPreference = findPreference<Preference>("about_us")
        aboutUsPreference?.setOnPreferenceClickListener {
            Toast.makeText(requireContext(), "برنامه قرآن - ساخته شده برای آموزش اندروید", Toast.LENGTH_LONG).show()
            true
        }
        // در SettingsFragment.kt
        override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences, key: String?) {
            when (key) {
                "enable_daily_reminder" -> {
                    val isEnabled = sharedPreferences.getBoolean(key, false)
                    if (isEnabled) {
                        reminderManager.scheduleDailyReminder(reminderHour, reminderMinute)
                        Toast.makeText(requireContext(), getString(R.string.daily_reminder_enabled), Toast.LENGTH_SHORT).show()
                    } else {
                        reminderManager.cancelDailyReminder()
                        Toast.makeText(requireContext(), getString(R.string.daily_reminder_disabled), Toast.LENGTH_SHORT).show()
                    }
                }
                "arabic_text_size", "translation_text_size", "show_translation" -> {
                    // Notify that text settings have changed
                    val intent = Intent("com.example.quranapp.TEXT_SETTINGS_CHANGED")
                    requireContext().sendBroadcast(intent)
                }
            }
        }

        // Set reminder time click listener
        val reminderTimePreference = findPreference<Preference>("reminder_time")
        reminderTimePreference?.setOnPreferenceClickListener {
            showTimePickerDialog()
            true
        }

        // Load saved reminder time
        val prefs = preferenceManager.sharedPreferences
        reminderHour = prefs?.getInt("reminder_hour", 8) ?: 8
        reminderMinute = prefs?.getInt("reminder_minute", 0) ?: 0

        // Update reminder time summary
        updateReminderTimeSummary()
    }

    override fun onResume() {
        super.onResume()
        preferenceManager.sharedPreferences?.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onPause() {
        super.onPause()
        preferenceManager.sharedPreferences?.unregisterOnSharedPreferenceChangeListener(this)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences, key: String?) {
        if (key == "enable_daily_reminder") {
            val isEnabled = sharedPreferences.getBoolean(key, false)
            if (isEnabled) {
                reminderManager.scheduleDailyReminder(reminderHour, reminderMinute)
                Toast.makeText(requireContext(), "یادآوری روزانه فعال شد", Toast.LENGTH_SHORT).show()
            } else {
                reminderManager.cancelDailyReminder()
                Toast.makeText(requireContext(), "یادآوری روزانه غیرفعال شد", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showTimePickerDialog() {
        TimePickerDialog(
            requireContext(),
            { _, hourOfDay, minute ->
                reminderHour = hourOfDay
                reminderMinute = minute

                // Save selected time
                preferenceManager.sharedPreferences?.edit()?.apply {
                    putInt("reminder_hour", reminderHour)
                    putInt("reminder_minute", reminderMinute)
                    apply()
                }

                // Update reminder time summary
                updateReminderTimeSummary()

                // If reminder is enabled, reschedule with new time
                val isEnabled = preferenceManager.sharedPreferences?.getBoolean("enable_daily_reminder", false) ?: false
                if (isEnabled) {
                    reminderManager.scheduleDailyReminder(reminderHour, reminderMinute)
                    Toast.makeText(requireContext(), "زمان یادآوری به‌روزرسانی شد", Toast.LENGTH_SHORT).show()
                }
            },
            reminderHour,
            reminderMinute,
            true
        ).show()
    }

    private fun updateReminderTimeSummary() {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, reminderHour)
            set(Calendar.MINUTE, reminderMinute)
        }

        val timeFormat = SimpleDateFormat("HH:mm", Locale("fa"))
        val timeString = timeFormat.format(calendar.time)

        findPreference<Preference>("reminder_time")?.summary = "زمان یادآوری: $timeString"
    }
}
