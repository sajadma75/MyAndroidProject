package com.example.quranapp.data

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.quranapp.data.models.Bookmark

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAllBookmarks(): LiveData<List<Bookmark>>

    @Query("SELECT * FROM bookmarks WHERE surahId = :surahId AND ayahId = :ayahId")
    fun getBookmark(surahId: Int, ayahId: Int): LiveData<Bookmark?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: Bookmark)

    @Delete
    suspend fun delete(bookmark: Bookmark)
}
