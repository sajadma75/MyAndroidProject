package com.example.quranapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.quranapp.data.models.Ayah
import com.example.quranapp.data.models.Bookmark
import com.example.quranapp.data.models.Surah

@Database(entities = [Surah::class, Ayah::class, Bookmark::class], version = 1, exportSchema = false)
abstract class QuranDatabase : RoomDatabase() {
    abstract fun surahDao(): SurahDao
    abstract fun ayahDao(): AyahDao
    abstract fun bookmarkDao(): BookmarkDao

    companion object {
        @Volatile
        private var INSTANCE: QuranDatabase? = null

        fun getDatabase(context: Context): QuranDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QuranDatabase::class.java,
                    "quran_database"
                )
                    .createFromAsset("database/quran.db")
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
