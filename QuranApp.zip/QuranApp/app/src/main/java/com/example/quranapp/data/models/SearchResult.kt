package com.example.quranapp.data.models

data class SearchResult(
    val surahId: Int,
    val surahName: String,
    val ayahId: Int,
    val ayahNumber: Int,
    val ayahText: String,
    val ayahTranslation: String
)
