package com.example.quranapp.data

import android.content.Context
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.quranapp.data.models.Ayah
import com.example.quranapp.data.models.Surah
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

class DataInitializer(private val context: Context) : RoomDatabase.Callback() {

    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)

        CoroutineScope(Dispatchers.IO).launch {
            val database = AppDatabase.getInstance(context)

            // Load Surahs
            val surahs = loadSurahsFromJson()
            database.surahDao().insertAll(surahs)

            // Load Ayahs
            val ayahs = loadAyahsFromJson()
            database.ayahDao().insertAll(ayahs)
        }
    }

    private fun loadSurahsFromJson(): List<Surah> {
        val surahs = mutableListOf<Surah>()
        try {
            val inputStream = context.assets.open("surahs.json")
            val reader = BufferedReader(InputStreamReader(inputStream))
            val jsonString = reader.readText()
            val jsonArray = JSONArray(jsonString)

            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val surah = Surah(
                    id = jsonObject.getInt("id"),
                    name = jsonObject.getString("name"),
                    nameArabic = jsonObject.getString("nameArabic"),
                    numberOfAyahs = jsonObject.getInt("numberOfAyahs"),
                    revelationType = jsonObject.getString("revelationType"),
                    nameTranslation = TODO(),
                    bismillahPre = TODO()
                )
                surahs.add(surah)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return surahs
    }

    private fun loadAyahsFromJson(): List<Ayah> {
        val ayahs = mutableListOf<Ayah>()
        try {
            val inputStream = context.assets.open("ayahs.json")
            val reader = BufferedReader(InputStreamReader(inputStream))
            val jsonString = reader.readText()
            val jsonArray = JSONArray(jsonString)

            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val ayah = Ayah(
                    id = jsonObject.getInt("id"),
                    surahId = jsonObject.getInt("surahId"),
                    ayahNumber = jsonObject.getInt("ayahNumber"),
                    text = jsonObject.getString("text"),
                    translation = jsonObject.getString("translation"),
                    audioUrl = jsonObject.getString("audioUrl")
                )
                ayahs.add(ayah)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return ayahs
    }
}
