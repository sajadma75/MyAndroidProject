package com.example.quranapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.quranapp.data.models.Surah
import com.example.quranapp.databinding.ItemSurahBinding

class SurahAdapter(private val onSurahClick: (Surah) -> Unit) :
    ListAdapter<Surah, SurahAdapter.SurahViewHolder>(SurahDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SurahViewHolder {
        val binding = ItemSurahBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return SurahViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SurahViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class SurahViewHolder(private val binding: ItemSurahBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onSurahClick(getItem(position))
                }
            }
        }

        fun bind(surah: Surah) {
            binding.apply {
                surahNumber.text = surah.id.toString()
                surahName.text = surah.name
                surahNameArabic.text = surah.nameArabic
                surahDetails.text = "${surah.numberOfAyahs} آیات • ${surah.revelationType}"
            }
        }
    }

    class SurahDiffCallback : DiffUtil.ItemCallback<Surah>() {
        override fun areItemsTheSame(oldItem: Surah, newItem: Surah): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Surah, newItem: Surah): Boolean {
            return oldItem == newItem
        }
    }
}
