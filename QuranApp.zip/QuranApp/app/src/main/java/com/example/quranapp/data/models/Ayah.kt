package com.example.quranapp.data.models

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "ayahs",
    foreignKeys = [
        ForeignKey(
            entity = Surah::class,
            parentColumns = ["id"],
            childColumns = ["surahId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Ayah(
    @PrimaryKey val id: Int,
    val surahId: Int,
    val ayahNumber: Int,
    val text: String,
    val translation: String,
    val audioUrl: String
)
