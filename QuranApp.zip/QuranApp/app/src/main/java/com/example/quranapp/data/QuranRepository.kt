package com.example.quranapp.data

import androidx.lifecycle.LiveData
import com.example.quranapp.data.models.Ayah
import com.example.quranapp.data.models.Bookmark
import com.example.quranapp.data.models.Surah

class QuranRepository(private val database: QuranDatabase) {
    // Surah related operations
    fun getAllSurahs(): LiveData<List<Surah>> {
        return database.surahDao().getAllSurahs()
    }

    fun getSurahById(surahId: Int): LiveData<Surah> {
        return database.surahDao().getSurahById(surahId)
    }

    // Ayah related operations
    fun getAyahsBySurah(surahId: Int): LiveData<List<Ayah>> {
        return database.ayahDao().getAyahsBySurah(surahId)
    }

    fun searchAyahs(query: String): LiveData<List<Ayah>> {
        return database.ayahDao().searchAyahs(query)
    }

    // Bookmark related operations
    fun getAllBookmarks(): LiveData<List<Bookmark>> {
        return database.bookmarkDao().getAllBookmarks()
    }

    fun getBookmark(surahId: Int, ayahId: Int): LiveData<Bookmark?> {
        return database.bookmarkDao().getBookmark(surahId, ayahId)
    }

    suspend fun addBookmark(bookmark: Bookmark) {
        database.bookmarkDao().insert(bookmark)
    }

    suspend fun removeBookmark(bookmark: Bookmark) {
        database.bookmarkDao().delete(bookmark)
    }
}
