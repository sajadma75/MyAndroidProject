package com.example.quranapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.quranapp.databinding.ActivityBookmarkBinding
import com.example.quranapp.ui.BookmarkAdapter
import com.example.quranapp.ui.MainViewModel

class BookmarkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBookmarkBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: BookmarkAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookmarkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        observeBookmarks()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "نشانک‌ها"
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun setupRecyclerView() {
        adapter = BookmarkAdapter(
            onBookmarkClick = { bookmarkWithDetails ->
                val intent = Intent(this, AyahListActivity::class.java).apply {
                    putExtra("SURAH_ID", bookmarkWithDetails.bookmark.surahId)
                    putExtra("SURAH_NAME", bookmarkWithDetails.surahName)
                    putExtra("SCROLL_TO_AYAH", bookmarkWithDetails.bookmark.ayahId)
                }
                startActivity(intent)
            },
            onRemoveClick = { bookmarkWithDetails ->
                viewModel.removeBookmark(bookmarkWithDetails.bookmark)
            }
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@BookmarkActivity)
            adapter = this@BookmarkActivity.adapter
        }
    }

    private fun observeBookmarks() {
        viewModel.getAllBookmarksWithDetails().observe(this) { bookmarks ->
            adapter.submitList(bookmarks)

            if (bookmarks.isEmpty()) {
                binding.emptyView.visibility = View.VISIBLE
                binding.recyclerView.visibility = View.GONE
            } else {
                binding.emptyView.visibility = View.GONE
                binding.recyclerView.visibility = View.VISIBLE
            }
        }
    }
}
