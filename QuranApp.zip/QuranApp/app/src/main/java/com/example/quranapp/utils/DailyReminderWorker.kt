package com.example.quranapp.utils

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.quranapp.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

class DailyReminderWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return withContext(Dispatchers.IO) {
            try {
                val database = AppDatabase.getInstance(applicationContext)
                val ayahDao = database.ayahDao()

                // Get a random ayah
                val allAyahsCount = ayahDao.getAyahsCount()
                if (allAyahsCount > 0) {
                    val randomId = Random.nextInt(1, allAyahsCount + 1)
                    val randomAyah = ayahDao.getAyahById(randomId)

                    // Show notification with this ayah
                    val notificationHelper = NotificationHelper(applicationContext)
                    notificationHelper.showDailyReminderNotification(randomAyah)

                    Result.success()
                } else {
                    Result.failure()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Result.failure()
            }
        }
    }
}
