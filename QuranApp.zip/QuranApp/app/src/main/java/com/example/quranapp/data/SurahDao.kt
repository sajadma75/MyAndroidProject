package com.example.quranapp.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.quranapp.data.models.Surah

@Dao
interface SurahDao {
    @Query("SELECT * FROM surahs ORDER BY id")
    fun getAllSurahs(): LiveData<List<Surah>>

    @Query("SELECT * FROM surahs WHERE id = :surahId")
    fun getSurahById(surahId: Int): LiveData<Surah>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(surahs: List<Surah>)
}
