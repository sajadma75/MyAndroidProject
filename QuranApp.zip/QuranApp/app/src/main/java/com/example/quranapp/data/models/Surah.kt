package com.example.quranapp.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "surahs")
data class Surah(
    @PrimaryKey val id: Int,
    val name: String,
    val nameArabic: String,
    val nameTranslation: String,
    val numberOfAyahs: Int,
    val revelationType: String,
    val bismillahPre: Boolean
)
