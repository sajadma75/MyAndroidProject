package com.example.quranapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.quranapp.databinding.ActivityMainBinding
import com.example.quranapp.ui.MainViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupClickListeners()
        updateDateTime()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.quran)
    }

    private fun setupClickListeners() {
        binding.cardQuran?.setOnClickListener {
            startActivity(Intent(this, SurahListActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        binding.cardBookmarks?.setOnClickListener {
            startActivity(Intent(this, BookmarkActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        binding.cardSearch?.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        binding.cardSettings?.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
    }

    private fun updateDateTime() {
        val calendar = Calendar.getInstance()

        // Update Hijri date
        val hijriYear = calendar.get(Calendar.YEAR) - 579 // تقریبی است
        val hijriMonth = getHijriMonthName(calendar.get(Calendar.MONTH))
        val hijriDay = calendar.get(Calendar.DAY_OF_MONTH)
        binding.textHijriDate?.text = "$hijriDay $hijriMonth $hijriYear هـ.ق"

        // Update Gregorian date
        val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale("fa"))
        binding.textGregorianDate?.text = dateFormat.format(Date())

        // Update day name
        val dayFormat = SimpleDateFormat("EEEE", Locale("fa"))
        binding.textDayName?.text = dayFormat.format(Date())
    }

    private fun getHijriMonthName(month: Int): String {
        return when (month) {
            0 -> "محرم"
            1 -> "صفر"
            2 -> "ربیع الاول"
            3 -> "ربیع الثانی"
            4 -> "جمادی الاول"
            5 -> "جمادی الثانی"
            6 -> "رجب"
            7 -> "شعبان"
            8 -> "رمضان"
            9 -> "شوال"
            10 -> "ذی القعده"
            11 -> "ذی الحجه"
            else -> ""
        }
    }
}
