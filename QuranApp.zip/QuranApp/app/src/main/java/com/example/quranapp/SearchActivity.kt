package com.example.quranapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.quranapp.databinding.ActivitySearchBinding
import com.example.quranapp.ui.MainViewModel
import com.example.quranapp.ui.SearchResultAdapter

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: SearchResultAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupSearchView()
        setupRecyclerView()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "جستجو در قرآن"
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun setupSearchView() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (!query.isNullOrBlank()) {
                    performSearch(query)
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (!newText.isNullOrBlank() && newText.length >= 3) {
                    performSearch(newText)
                } else {
                    // Clear results if search query is too short
                    adapter.submitList(emptyList())
                    showEmptyView(true)
                }
                return true
            }
        })
    }

    private fun setupRecyclerView() {
        adapter = SearchResultAdapter { searchResult ->
            val intent = Intent(this, AyahListActivity::class.java).apply {
                putExtra("SURAH_ID", searchResult.surahId)
                putExtra("SURAH_NAME", searchResult.surahName)
                putExtra("SCROLL_TO_AYAH", searchResult.ayahId)
            }
            startActivity(intent)
        }

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@SearchActivity)
            adapter = this@SearchActivity.adapter
        }
    }

    private fun performSearch(query: String) {
        viewModel.searchQuran(query).observe(this) { results ->
            adapter.submitList(results)
            showEmptyView(results.isEmpty())

            if (results.isEmpty()) {
                binding.emptyView.text = "نتیجه‌ای یافت نشد"
            }
        }
    }

    private fun showEmptyView(show: Boolean) {
        if (show) {
            binding.emptyView.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.GONE
        } else {
            binding.emptyView.visibility = View.GONE
            binding.recyclerView.visibility = View.VISIBLE
        }
    }
}
