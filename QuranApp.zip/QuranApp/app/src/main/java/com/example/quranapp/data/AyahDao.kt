package com.example.quranapp.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.quranapp.data.models.Ayah

@Dao
interface AyahDao {
    @Query("SELECT COUNT(*) FROM ayahs")
    fun getAyahsCount(): Int

    @Query("SELECT * FROM ayahs WHERE id = :id")
    fun getAyahById(id: Int): Ayah

    @Query("SELECT * FROM ayahs WHERE surahId = :surahId ORDER BY ayahNumber")
    fun getAyahsBySurah(surahId: Int): LiveData<List<Ayah>>

    @Query("SELECT * FROM ayahs WHERE id = :ayahId")
    fun getAyahByIdLive(ayahId: Int): LiveData<Ayah>  // نام متد تغییر کرد

    @Query("SELECT * FROM ayahs WHERE text LIKE '%' || :query || '%' OR translation LIKE '%' || :query || '%'")
    fun searchAyahs(query: String): LiveData<List<Ayah>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(ayahs: List<Ayah>)
}
